package io.github.disctester;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

public class SpeedChartView extends View {
    private List<Float> readSpeeds = new ArrayList<Float>();
    private List<Float> writeSpeeds = new ArrayList<Float>();
    private Paint readPaint, writePaint, gridPaint, textPaint;
    private float maxValue = 1.0f;
    private boolean isDark = false;

    public SpeedChartView(Context context) { 
        super(context); 
        init(); 
    }

    public SpeedChartView(Context context, AttributeSet attrs) { 
        super(context, attrs); 
        init(); 
    }

    public void setDarkMode(boolean dark) { 
        isDark = dark; 
        postInvalidate(); 
    }

    private void init() {
        readPaint = new Paint();
        readPaint.setColor(Color.parseColor("#D32F2F"));
        readPaint.setStrokeWidth(3);
        readPaint.setStyle(Paint.Style.STROKE);
        readPaint.setAntiAlias(true);

        writePaint = new Paint();
        writePaint.setColor(Color.parseColor("#1976D2"));
        writePaint.setStrokeWidth(3);
        writePaint.setStyle(Paint.Style.STROKE);
        writePaint.setAntiAlias(true);

        gridPaint = new Paint();
        gridPaint.setColor(Color.parseColor("#E0E0E0"));
        gridPaint.setStrokeWidth(1);

        textPaint = new Paint();
        textPaint.setColor(Color.parseColor("#757575"));
        textPaint.setTextSize(12);
        textPaint.setAntiAlias(true);
    }

    public void addDataPoints(float read, float write) {
        readSpeeds.add(read);
        writeSpeeds.add(write);
        float max = Math.max(read, write);
        if (max > maxValue) maxValue = max;
        if (readSpeeds.size() > 30) {
            readSpeeds.remove(0);
            writeSpeeds.remove(0);
        }
        postInvalidate();
    }

    public void clear() {
        readSpeeds.clear();
        writeSpeeds.clear();
        maxValue = 1.0f;
        postInvalidate();
    }

    //修复折线问题
    public void setMaxValue(float max) {
        maxValue = max;
        postInvalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int width = getWidth();
        int height = getHeight();
        int padding = 50;
        int chartHeight = height - padding * 2;
        int chartWidth = width - padding * 2;

        // 网格与Y轴
        for (int i = 0; i <= 4; i++) {
            float y = padding + (chartHeight / 4.0f) * i;
            canvas.drawLine(padding, y, width - padding, y, gridPaint);
            float value = maxValue - (maxValue / 4.0f) * i;
            canvas.drawText(String.format("%.1f", value), 5, y + 4, textPaint);
        }

        // 时间轴严格对齐
        float pointSpacing = chartWidth / 29.0f;
        for (int i = 0; i <= 5; i++) {
            int pointIndex = i * 6;
            if (pointIndex > 29) pointIndex = 29;
            float x = padding + pointIndex * pointSpacing;
            canvas.drawText((i * 3) + "s", x - 10, height - 10, textPaint);
        }

        if (!readSpeeds.isEmpty() && maxValue > 0) {
            Path readPath = new Path();
            Path writePath = new Path();

            float startY_R = padding + chartHeight - (readSpeeds.get(0) / maxValue) * chartHeight;
            float startY_W = padding + chartHeight - (writeSpeeds.get(0) / maxValue) * chartHeight;
            readPath.moveTo(padding, startY_R);
            writePath.moveTo(padding, startY_W);

            for (int i = 1; i < readSpeeds.size(); i++) {
                float x = padding + i * pointSpacing;
                float yR = padding + chartHeight - (readSpeeds.get(i) / maxValue) * chartHeight;
                float yW = padding + chartHeight - (writeSpeeds.get(i) / maxValue) * chartHeight;
                readPath.lineTo(x, yR);
                writePath.lineTo(x, yW);
            }
            canvas.drawPath(readPath, readPaint);
            canvas.drawPath(writePath, writePaint);
        }

        // 边框
        Paint borderPaint = new Paint();
        borderPaint.setColor(isDark ? Color.parseColor("#444444") : Color.parseColor("#BDBDBD"));
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(1);
        canvas.drawRect(padding, padding, width - padding, height - padding, borderPaint);

        // 图例
        textPaint.setColor(isDark ? Color.parseColor("#E0E0E0") : Color.parseColor("#424242"));
        canvas.drawText("●Read(读速)", padding, padding - 15, textPaint);
        canvas.drawText("●Write(存速)", padding + 80, padding - 15, textPaint);
    }
}
