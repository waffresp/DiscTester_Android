package io.github.disctester;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.StatFs;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public class MainActivity extends Activity {

    private Spinner storageSpinner;
    private Button btnRefreshStorage;
    private String[] storageOptions = new String[0];
    private File[] storageDirs = new File[0];

    private Button btnStart, btnContinuous;
    private TextView tvStatus;
    private TextView tvSeqWrite, tvSeqRead, tvRandWrite, tvRandRead;
    private ProgressBar progressBar;

    private SpeedChartView chartView;
    private TextView tvAvgSpeed, tvMaxSpeed, tvMinSpeed, tvDuration;
    private LinearLayout chartContainer;

    private Button btnAbout, btnClearCache, btnStorageInfo;

    private Handler mainHandler;
    private boolean isTesting = false;
    private boolean isContinuousTesting = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainHandler = new Handler(Looper.getMainLooper());

        try {
            detectStorageDevices();

            LinearLayout rootLayout = new LinearLayout(this);
            rootLayout.setOrientation(LinearLayout.VERTICAL);
            rootLayout.setBackgroundColor(Color.parseColor("#FAFAFA"));

            createHeader(rootLayout);
            createContent(rootLayout);
            createButtons(rootLayout);
            createBottomBar(rootLayout);

            setContentView(rootLayout);
            Toast.makeText(this, "让我们恭喜DT再一次启动成功", Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            showError("启动失败: " + e.getMessage());
        }
    }

    private void detectStorageDevices() {
        List<String> labels = new ArrayList<String>();
        List<File> dirs = new ArrayList<File>();
        File[] externalCaches = getExternalCacheDirs();
        if (externalCaches != null) {
            for (File dir : externalCaches) {
                if (dir != null && isWritableDir(dir) && !dirs.contains(dir)) {
                    labels.add(getStorageLabel(dir));
                    dirs.add(dir);
                }
            }
        }
        File internalCache = getCacheDir();
        if (isWritableDir(internalCache) && !dirs.contains(internalCache)) {
            labels.add(0, "内部存储 (默认存储)");
            dirs.add(0, internalCache);
        }
        storageOptions = labels.toArray(new String[0]);
        storageDirs = dirs.toArray(new File[0]);

        if (storageSpinner != null && storageOptions.length > 0) {
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, 
																	android.R.layout.simple_spinner_item, storageOptions);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            storageSpinner.setAdapter(adapter);
            storageSpinner.setSelection(0);
        }
    }

    private boolean isWritableDir(File dir) {
        return dir != null && dir.exists() && dir.canWrite();
    }

    private String getStorageLabel(File dir) {
        String path = dir.getAbsolutePath();
        if (path.contains("emulated") || path.contains("internal")) {
            return "内部存储 (默认存储)";
        }
        String[] parts = path.split("/");
        String mount = parts.length > 2 ? parts[2] : "外部存储";
        return "外部存储 (" + mount + ")";
    }

    private void createHeader(LinearLayout parent) {
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setBackgroundColor(Color.parseColor("#1976D2"));
        header.setPadding(20, 25, 20, 25);
        header.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout titleGroup = new LinearLayout(this);
        titleGroup.setOrientation(LinearLayout.VERTICAL);
        titleGroup.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        TextView title = new TextView(this);
        title.setText("DiscTester v0.5");
        title.setTextSize(20);
        title.setTextColor(Color.WHITE);

        TextView subtitle = new TextView(this);
        subtitle.setText("代码能跑起来就不要动了……");
        subtitle.setTextSize(12);
        subtitle.setTextColor(Color.parseColor("#B3FFFFFF"));

        titleGroup.addView(title);
        titleGroup.addView(subtitle);

        storageSpinner = new Spinner(this);
        storageSpinner.setBackgroundColor(Color.parseColor("#1565C0"));
        storageSpinner.setPadding(10, 10, 10, 10);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, 
																android.R.layout.simple_spinner_item, storageOptions);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        storageSpinner.setAdapter(adapter);

        btnRefreshStorage = new Button(this);
        btnRefreshStorage.setText("刷新设备");
        btnRefreshStorage.setTextSize(12);
        btnRefreshStorage.setTextColor(Color.WHITE);
        btnRefreshStorage.setBackgroundColor(Color.parseColor("#0D47A1"));
        btnRefreshStorage.setPadding(15, 10, 15, 10);
        btnRefreshStorage.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					detectStorageDevices();
					Toast.makeText(MainActivity.this, "设备列表已更新", Toast.LENGTH_SHORT).show();
				}
			});

        header.addView(titleGroup);
        header.addView(storageSpinner);
        header.addView(btnRefreshStorage);
        parent.addView(header);
    }

    private void createContent(LinearLayout parent) {
        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(15, 15, 15, 15);

        tvStatus = createText("准备就绪", 16, Color.parseColor("#212121"));
        tvStatus.setTypeface(null, android.graphics.Typeface.BOLD);

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setLayoutParams(new LinearLayout.LayoutParams(
										LinearLayout.LayoutParams.MATCH_PARENT, 10));

        LinearLayout card1 = createWhiteCard();
        card1.setOrientation(LinearLayout.VERTICAL);
        card1.addView(createText("标准测试结果", 14, Color.parseColor("#757575")));

        tvSeqWrite = createResultText("顺序写入: --");
        tvSeqRead = createResultText("顺序读取: --");
        tvRandWrite = createResultText("随机写入: --");
        tvRandRead = createResultText("随机读取: --");

        card1.addView(tvSeqWrite);
        card1.addView(tvSeqRead);
        card1.addView(tvRandWrite);
        card1.addView(tvRandRead);

        chartContainer = createWhiteCard();
        chartContainer.setOrientation(LinearLayout.VERTICAL);
        chartContainer.setVisibility(View.GONE);

        chartView = new SpeedChartView(this);
        chartView.setLayoutParams(new LinearLayout.LayoutParams(
									  LinearLayout.LayoutParams.MATCH_PARENT, 280));

        tvAvgSpeed = createText("平均 读: -- | 写: -- MB/s", 13, Color.parseColor("#616161"));
        tvMaxSpeed = createText("峰值 读: -- | 写: -- MB/s", 13, Color.parseColor("#616161"));
        tvMinSpeed = createText("谷值 读: -- | 写: -- MB/s", 13, Color.parseColor("#616161"));
        tvDuration = createText("时长: 0s", 13, Color.parseColor("#616161"));

        chartContainer.addView(chartView);
        chartContainer.addView(tvAvgSpeed);
        chartContainer.addView(tvMaxSpeed);
        chartContainer.addView(tvMinSpeed);
        chartContainer.addView(tvDuration);

        content.addView(tvStatus);
        content.addView(progressBar);
        content.addView(card1);
        content.addView(chartContainer);

        scroll.addView(content);
        parent.addView(scroll);
    }

    private void createButtons(LinearLayout parent) {
        LinearLayout btnLayout = new LinearLayout(this);
        btnLayout.setOrientation(LinearLayout.VERTICAL);
        btnLayout.setGravity(Gravity.CENTER_HORIZONTAL);
        btnLayout.setPadding(20, 15, 20, 25);

        btnStart = createBlueButton("标准测试", new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					if (!isContinuousTesting) startStandardTest();
				}
			});

        btnContinuous = createBlueButton("持续读写测试(15秒)", new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					if (!isTesting) startContinuousTest();
				}
			});

        btnLayout.addView(btnStart);
        btnLayout.addView(btnContinuous);
        parent.addView(btnLayout);
    }

    private void createBottomBar(LinearLayout parent) {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setPadding(15, 12, 15, 20);
        bar.setBackgroundColor(Color.parseColor("#F5F5F5"));

        btnStorageInfo = createSimpleButton("存储设备详情", new View.OnClickListener() {
				@Override
				public void onClick(View v) { showStorageInfo(); }
			});

        btnAbout = createSimpleButton("i 关于", new View.OnClickListener() {
				@Override
				public void onClick(View v) { showAbout(); }
			});

        btnClearCache = createSimpleButton("清除缓存", new View.OnClickListener() {
				@Override
				public void onClick(View v) { clearCache(); }
			});
        btnClearCache.setTextColor(Color.parseColor("#D32F2F"));

        bar.addView(btnStorageInfo);
        View spacer1 = new View(this);
        spacer1.setLayoutParams(new LinearLayout.LayoutParams(0, 1, 1));
        bar.addView(spacer1);
        bar.addView(btnAbout);
        View spacer2 = new View(this);
        spacer2.setLayoutParams(new LinearLayout.LayoutParams(0, 1, 1));
        bar.addView(spacer2);
        bar.addView(btnClearCache);
        parent.addView(bar);
    }

    private LinearLayout createWhiteCard() {
        LinearLayout card = new LinearLayout(this);
        card.setBackgroundColor(Color.WHITE);
        card.setPadding(20, 20, 20, 20);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(12);
        card.setBackground(bg);
        card.setElevation(2);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, 10, 0, 10);
        card.setLayoutParams(params);
        return card;
    }

    private TextView createText(String text, int size, int color) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(size);
        tv.setTextColor(color);
        tv.setPadding(0, 8, 0, 8);
        return tv;
    }

    private TextView createResultText(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(14);
        tv.setTextColor(Color.parseColor("#1976D2"));
        tv.setPadding(0, 10, 0, 10);
        return tv;
    }

    private Button createBlueButton(String text, View.OnClickListener listener) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextSize(15);
        btn.setTextColor(Color.WHITE);
        btn.setPadding(30, 12, 30, 12);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1976D2"));
        bg.setCornerRadius(20);
        btn.setBackground(bg);
        btn.setOnClickListener(listener);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, 10, 0, 10);
        btn.setLayoutParams(params);
        return btn;
    }

    private Button createSimpleButton(String text, View.OnClickListener listener) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextSize(12);
        btn.setBackgroundColor(Color.TRANSPARENT);
        btn.setPadding(10, 8, 10, 8);
        btn.setOnClickListener(listener);
        return btn;
    }

    // ========== 存储详情功能 (已修复兼容性问题) ==========
    private void showStorageInfo() {
        if (storageDirs.length == 0) return;
        final File dir = storageDirs[storageSpinner.getSelectedItemPosition()];
        try {
            final StatFs stat = new StatFs(dir.getAbsolutePath());
            final long blockSize = stat.getBlockSizeLong();
            final long totalBlocks = stat.getBlockCountLong();
            final long availBlocks = stat.getAvailableBlocksLong();

            final long totalSpace = totalBlocks * blockSize;
            final long availSpace = availBlocks * blockSize;

            String info = "📍 路径: " + dir.getAbsolutePath() + "\n\n" +
				"总容量: " + formatSize(totalSpace) + "\n" +
				"可用空间: " + formatSize(availSpace) + "\n" +
				"块大小: " + formatSize(blockSize) + "\n" +
				"文件系统(不准确): " + detectFileSystem(dir);

            new AlertDialog.Builder(this)
                .setTitle("存储介质详情")
                .setMessage(info)
                .setPositiveButton("确定", null)
                .show();
        } catch (Exception e) {
            Toast.makeText(this, "获取信息失败: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private String formatSize(long bytes) {
        if (bytes >= 1073741824) return String.format(Locale.US, "%.2f GB", bytes / 1073741824.0);
        if (bytes >= 1048576) return String.format(Locale.US, "%.2f MB", bytes / 1048576.0);
        return String.format(Locale.US, "%.2f KB", bytes / 1024.0);
    }

    //抛弃android.system，拥抱StatFS!!!
    private String detectFileSystem(File dir) {
        try {
            StatFs stat = new StatFs(dir.getAbsolutePath());
            long blockSize = stat.getBlockSizeLong();
            long totalBlocks = stat.getBlockCountLong();
            long totalSpace = blockSize * totalBlocks;

            if (totalSpace > 10737418240L) {
                if (blockSize == 4096) return "ext4 / F2FS";
                if (blockSize == 1024 || blockSize == 2048) return "FAT32";
                if (blockSize == 8192) return "exFAT";
				//根据算法大致推断
            }
            return "ext4 / F2FS (Android 标准)";
        } catch (Exception e) {
            return "未知 (权限受限)";
        }
    }

    // ========== 测试逻辑 ==========
    private void startStandardTest() {
        if (storageDirs.length == 0) {
            Toast.makeText(this, "未找到可用存储设备", Toast.LENGTH_LONG).show();
            return;
        }
        isTesting = true;
        btnStart.setEnabled(false);
        tvStatus.setText("测试中...");
        chartContainer.setVisibility(View.GONE);

        new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						final File testDir = storageDirs[storageSpinner.getSelectedItemPosition()];
						if (!testDir.exists()) testDir.mkdirs();

						final File testFile = new File(testDir, "test.bin");
						if (testFile.exists()) testFile.delete();
						testFile.createNewFile();

						long size = 20 * 1024 * 1024;
						byte[] buffer = new byte[1024 * 1024];

						RandomAccessFile raf = new RandomAccessFile(testFile, "rw");
						long start = System.nanoTime();
						long written = 0;
						while (written < size) {
							int chunk = (int) Math.min(buffer.length, size - written);
							raf.write(buffer, 0, chunk);
							written += chunk;
						}
						raf.close();
						final double seqWrite = calcSpeed(size, start);

						raf = new RandomAccessFile(testFile, "r");
						start = System.nanoTime();
						while (raf.read(buffer) != -1) {}
						raf.close();
						final double seqRead = calcSpeed(size, start);

						raf = new RandomAccessFile(testFile, "rw");
						buffer = new byte[4096];
						Random rand = new Random();
						start = System.nanoTime();
						for (int i = 0; i < 500; i++) {
							raf.seek(rand.nextInt((int)(size - 4096)));
							raf.write(buffer);
						}
						raf.close();
						final double randWrite = calcSpeed(500L * 4096, start);

						raf = new RandomAccessFile(testFile, "r");
						buffer = new byte[4096];
						start = System.nanoTime();
						for (int i = 0; i < 500; i++) {
							raf.seek(rand.nextInt((int)(size - 4096)));
							raf.read(buffer);
						}
						raf.close();
						final double randRead = calcSpeed(500L * 4096, start);

						testFile.delete();

						mainHandler.post(new Runnable() {
								@Override
								public void run() {
									tvSeqWrite.setText(String.format(Locale.US, "顺序写入: %.2f MB/s", seqWrite));
									tvSeqRead.setText(String.format(Locale.US, "顺序读取: %.2f MB/s", seqRead));
									tvRandWrite.setText(String.format(Locale.US, "随机写入: %.2f MB/s", randWrite));
									tvRandRead.setText(String.format(Locale.US, "随机读取: %.2f MB/s", randRead));
									tvStatus.setText("测试完成");
									btnStart.setEnabled(true);
									isTesting = false;
								}
							});
					} catch (final Exception e) {
						mainHandler.post(new Runnable() {
								@Override
								public void run() {
									tvStatus.setText("测试失败");
									Toast.makeText(MainActivity.this, "错误: " + e.getMessage(), Toast.LENGTH_LONG).show();
									btnStart.setEnabled(true);
									isTesting = false;
								}
							});
					}
				}
			}).start();
    }

    private void startContinuousTest() {
        if (storageDirs.length == 0) {
            Toast.makeText(this, "未找到可用存储设备", Toast.LENGTH_LONG).show();
            return;
        }
        isContinuousTesting = true;
        isTesting = true;
        btnContinuous.setEnabled(false);
        tvStatus.setText("持续读写测试中...");
        chartContainer.setVisibility(View.VISIBLE);
        if (chartView != null) chartView.clear();

        final List<Float> readSpeeds = new ArrayList<Float>();
        final List<Float> writeSpeeds = new ArrayList<Float>();
        final long startTime = System.currentTimeMillis();
        final long testDuration = 15000;
        final long sampleInterval = 1000;

        new Thread(new Runnable() {
				@Override
				public void run() {
					File testFile = null;
					try {
						final File testDir = storageDirs[storageSpinner.getSelectedItemPosition()];
						if (!testDir.exists()) testDir.mkdirs();

						testFile = new File(testDir, "rw_bench.bin");
						if (testFile.exists()) testFile.delete();
						testFile.createNewFile();

						// 预填充 50MB 防止顺序写入优化
						RandomAccessFile raf = new RandomAccessFile(testFile, "rw");
						byte[] fillBuf = new byte[1024 * 1024];
						for(int i=0; i<50; i++) raf.write(fillBuf);
						raf.close();

						raf = new RandomAccessFile(testFile, "rw");
						byte[] buffer = new byte[1024 * 1024];
						Random rand = new Random();

						long lastSampleTime = System.currentTimeMillis();
						long ioBytesR = 0, ioBytesW = 0;
						long ioTimeRNs = 0, ioTimeWNs = 0;

						while (System.currentTimeMillis() - startTime < testDuration && isContinuousTesting) {
							long fileSize = testFile.length();
							if (fileSize < 50 * 1024 * 1024) {
								raf.seek(fileSize);
								raf.write(buffer);
								fileSize = testFile.length();
							}

							long pos = rand.nextInt((int) Math.max(1, fileSize - buffer.length));

							// ✅ 精准计时：仅计算实际数据传输时间，排除 seek()
							long opStart = System.nanoTime();
							raf.seek(pos); 
							raf.write(buffer);
							ioTimeWNs += System.nanoTime() - opStart;
							ioBytesW += buffer.length;

							pos = rand.nextInt((int) Math.max(1, fileSize - buffer.length));
							opStart = System.nanoTime();
							raf.seek(pos);
							raf.read(buffer);
							ioTimeRNs += System.nanoTime() - opStart;
							ioBytesR += buffer.length;

							long now = System.currentTimeMillis();
							if (now - lastSampleTime >= sampleInterval) {
								double speedW = (ioBytesW / 1048576.0) / (ioTimeWNs / 1_000_000_000.0);
								double speedR = (ioBytesR / 1048576.0) / (ioTimeRNs / 1_000_000_000.0);

								readSpeeds.add((float)speedR);
								writeSpeeds.add((float)speedW);

								final float rSpd = (float)speedR;
								final float wSpd = (float)speedW;
								final int seconds = (int)((now - startTime) / 1000);

								mainHandler.post(new Runnable() {
										@Override
										public void run() {
											if (chartView != null) chartView.addDataPoints(rSpd, wSpd);
											tvDuration.setText("时长: " + seconds + "s");
										}
									});

								ioBytesR = 0; ioBytesW = 0;
								ioTimeRNs = 0; ioTimeWNs = 0;
								lastSampleTime = now;
							}
						}
						raf.close();

						float maxR = 0, maxW = 0, minR = Float.MAX_VALUE, minW = Float.MAX_VALUE;
						float sumR = 0, sumW = 0;
						for (float s : readSpeeds) { maxR = Math.max(maxR, s); minR = Math.min(minR, s); sumR += s; }
						for (float s : writeSpeeds) { maxW = Math.max(maxW, s); minW = Math.min(minW, s); sumW += s; }

						final float avgR = readSpeeds.isEmpty() ? 0 : sumR / readSpeeds.size();
						final float avgW = writeSpeeds.isEmpty() ? 0 : sumW / writeSpeeds.size();
						final float finalMaxR = maxR, finalMaxW = maxW;
						final float finalMinR = minR, finalMinW = minW;

						mainHandler.post(new Runnable() {
								@Override
								public void run() {
									tvAvgSpeed.setText(String.format(Locale.US, "平均 读: %.2f | 写: %.2f MB/s", avgR, avgW));
									tvMaxSpeed.setText(String.format(Locale.US, "峰值 读: %.2f | 写: %.2f MB/s", finalMaxR, finalMaxW));
									tvMinSpeed.setText(String.format(Locale.US, "谷值 读: %.2f | 写: %.2f MB/s", finalMinR, finalMinW));
									if (chartView != null) chartView.setMaxValue(Math.max(finalMaxR, finalMaxW) * 1.2f);
								}
							});

						mainHandler.post(new Runnable() {
								@Override
								public void run() {
									tvStatus.setText("持续测试完成");
									btnContinuous.setEnabled(true);
									isTesting = false;
									isContinuousTesting = false;
								}
							});

					} catch (final Exception e) {
						mainHandler.post(new Runnable() {
								@Override
								public void run() {
									tvStatus.setText("测试失败");
									Toast.makeText(MainActivity.this, "错误: " + e.getMessage(), Toast.LENGTH_LONG).show();
									btnContinuous.setEnabled(true);
									isTesting = false;
									isContinuousTesting = false;
								}
							});
					} finally {
						//强制清理：无论成功失败，立即删除临时文件
						if (testFile != null && testFile.exists()) {
							testFile.delete();
						}
					}
				}
			}).start();
    }

    private void clearCache() {
        try {
            deleteDir(getCacheDir());
            File[] extCaches = getExternalCacheDirs();
            if (extCaches != null) {
                for (File dir : extCaches) if (dir != null) deleteDir(dir);
            }
            Toast.makeText(this, "缓存已清除", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "清除失败", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteDir(File dir) {
        if (dir.isDirectory()) {
            File[] files = dir.listFiles();
            if (files != null) for (File f : files) deleteDir(f);
        }
        dir.delete();
    }

    private void showAbout() {
        new AlertDialog.Builder(this)
            .setTitle("关于 DiscTester")
            .setMessage("存储测试DT，一个我开发的测速应用 v0.5\n\n" +
                        "v0.5 更新日志:\n" +
                        "1.新增存储介质详情\n" +
                        "2.修复写入速度计时偏差(早就想改了)\n" +
                        "3.纯IO写入测速(不然不精准)\n" +
                        "4.自动清理再次优化\n\n" +
                        "By waffme(w3_Dev)")
            .setPositiveButton("确定", null)
            .show();
    }

    private void showError(String msg) {
        TextView tv = new TextView(this);
        tv.setText(msg);
        tv.setPadding(20, 20, 20, 20);
        setContentView(tv);
    }

    private double calcSpeed(long bytes, long startNano) {
        double seconds = (System.nanoTime() - startNano) / 1_000_000_000.0;
        return (bytes / 1048576.0) / seconds;
    }
}
