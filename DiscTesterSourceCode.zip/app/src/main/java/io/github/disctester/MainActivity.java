package io.github.disctester;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.StatFs;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public class MainActivity extends Activity {

    private Spinner storageSpinner;
    private Button btnRefreshStorage;
    private String[] storageOptions = new String[0];
    private File[] storageDirs = new File[0];

    private Button btnStart, btnContinuous;
    private TextView tvStatus;
    private TextView tvSeqWrite, tvSeqRead, tvRandWrite, tvRandRead;
    private ProgressBar progressBar;

    private SpeedChartView chartView;
    private TextView tvAvgSpeed, tvMaxSpeed, tvMinSpeed, tvDuration;
    private LinearLayout chartContainer;

    private Button btnAbout, btnClearCache, btnStorageInfo, btnLanguage;

    private Handler mainHandler;
    private boolean isTesting = false;
    private boolean isContinuousTesting = false;
    private boolean isEnglish = false;
    private File currentBrowseDir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainHandler = new Handler(Looper.getMainLooper());

        try {
            detectStorageDevices();

            LinearLayout rootLayout = new LinearLayout(this);
            rootLayout.setOrientation(LinearLayout.VERTICAL);
            rootLayout.setBackgroundColor(Color.parseColor("#FAFAFA"));

            createHeader(rootLayout);
            createContent(rootLayout);
            createButtons(rootLayout);
            createBottomBar(rootLayout);

            setContentView(rootLayout);
            showToast(isEnglish ? "DiscTester v0.6 launched successfully!!!" : "DiscTester再一次成功工作");

        } catch (Exception e) {
            showError("启动失败: " + e.getMessage());
        }
    }

    private void toggleLanguage() {
        isEnglish = !isEnglish;
        updateAllText();
        showToast(isEnglish ? "Language: English" : "语言：中文");
    }

    private void updateAllText() {
        if (btnStart != null) btnStart.setText(isEnglish ? "Standard Test" : "标准测试");
        if (btnContinuous != null) btnContinuous.setText(isEnglish ? "Continuous R/W (15s)" : "持续读写测试(15秒)");
        if (btnStorageInfo != null) btnStorageInfo.setText(isEnglish ? "Storage Info" : "存储详情");
        if (btnAbout != null) btnAbout.setText(isEnglish ? "About" : "关于");
        if (btnClearCache != null) btnClearCache.setText(isEnglish ? "Clear Cache" : "清除缓存");
        if (btnLanguage != null) btnLanguage.setText(isEnglish ? "EN" : "中文");
        if (btnRefreshStorage != null) btnRefreshStorage.setText(isEnglish ? "Refresh" : "刷新");

        if (tvStatus != null) tvStatus.setText(isEnglish ? "Ready" : "准备就绪");
        if (tvSeqWrite != null) tvSeqWrite.setText(isEnglish ? "Sequential Write: --" : "顺序写入: --");
        if (tvSeqRead != null) tvSeqRead.setText(isEnglish ? "Sequential Read: --" : "顺序读取: --");
        if (tvRandWrite != null) tvRandWrite.setText(isEnglish ? "Random Write: --" : "随机写入: --");
        if (tvRandRead != null) tvRandRead.setText(isEnglish ? "Random Read: --" : "随机读取: --");
    }

    private String getUIText(int key) {
        switch(key) {
            case 1: return isEnglish ? "DiscTester v0.6" : "DiscTester v0.6";
            case 2: return isEnglish ? "It works or may not……" : "代码能够运行就不要再动了……";
            case 3: return isEnglish ? "Internal Storage (App)" : "内部存储 (应用)";
            case 4: return isEnglish ? "External Storage" : "外部存储";
            case 5: return isEnglish ? "Standard Test Results" : "标准测试结果";
            case 6: return isEnglish ? "Avg R: -- | W: -- MB/s" : "平均 读: -- | 写: -- MB/s";
            case 7: return isEnglish ? "Peak R: -- | W: -- MB/s" : "峰值 读: -- | 写: -- MB/s";
            case 8: return isEnglish ? "Min R: -- | W: -- MB/s" : "谷值 读: -- | 写: -- MB/s";
            case 9: return isEnglish ? "Duration: 0s" : "时长: 0s";
            default: return "";
        }
    }

    private void detectStorageDevices() {
        List<String> labels = new ArrayList<String>();
        List<File> dirs = new ArrayList<File>();
        File[] externalCaches = getExternalCacheDirs();
        if (externalCaches != null) {
            for (File dir : externalCaches) {
                if (dir != null && isWritableDir(dir) && !dirs.contains(dir)) {
                    labels.add(getStorageLabel(dir));
                    dirs.add(dir);
                }
            }
        }
        File internalCache = getCacheDir();
        if (isWritableDir(internalCache) && !dirs.contains(internalCache)) {
            labels.add(0, getUIText(3));
            dirs.add(0, internalCache);
        }
        storageOptions = labels.toArray(new String[0]);
        storageDirs = dirs.toArray(new File[0]);

        if (storageSpinner != null && storageOptions.length > 0) {
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, 
																	android.R.layout.simple_spinner_item, storageOptions);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            storageSpinner.setAdapter(adapter);
            storageSpinner.setSelection(0);
        }
    }

    private boolean isWritableDir(File dir) {
        return dir != null && dir.exists() && dir.canWrite();
    }

    private String getStorageLabel(File dir) {
        String path = dir.getAbsolutePath();
        if (path.contains("emulated") || path.contains("internal")) {
            return getUIText(3);
        }
        String[] parts = path.split("/");
        String mount = parts.length > 2 ? parts[2] : getUIText(4);
        return getUIText(4) + " (" + mount + ")";
    }

    private void createHeader(LinearLayout parent) {
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setBackgroundColor(Color.parseColor("#1976D2"));
        header.setPadding(20, 25, 20, 25);
        header.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout titleGroup = new LinearLayout(this);
        titleGroup.setOrientation(LinearLayout.VERTICAL);
        titleGroup.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        TextView title = new TextView(this);
        title.setText(getUIText(1));
        title.setTextSize(20);
        title.setTextColor(Color.WHITE);

        TextView subtitle = new TextView(this);
        subtitle.setText(getUIText(2));
        subtitle.setTextSize(12);
        subtitle.setTextColor(Color.parseColor("#B3FFFFFF"));

        titleGroup.addView(title);
        titleGroup.addView(subtitle);

        storageSpinner = new Spinner(this);
        storageSpinner.setBackgroundColor(Color.parseColor("#1565C0"));
        storageSpinner.setPadding(10, 10, 10, 10);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, 
																android.R.layout.simple_spinner_item, storageOptions);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        storageSpinner.setAdapter(adapter);

        btnRefreshStorage = new Button(this);
        btnRefreshStorage.setText(isEnglish ? "Refresh" : "刷新");
        btnRefreshStorage.setTextSize(12);
        btnRefreshStorage.setTextColor(Color.WHITE);
        btnRefreshStorage.setBackgroundColor(Color.parseColor("#0D47A1"));
        btnRefreshStorage.setPadding(15, 10, 15, 10);
        btnRefreshStorage.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					detectStorageDevices();
					showToast(isEnglish ? "Device list updated" : "设备列表已更新");
				}
			});

        header.addView(titleGroup);
        header.addView(storageSpinner);
        header.addView(btnRefreshStorage);
        parent.addView(header);
    }

    private void createContent(LinearLayout parent) {
        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(15, 15, 15, 15);

        tvStatus = createText(isEnglish ? "Ready" : "准备就绪", 16, Color.parseColor("#212121"));
        tvStatus.setTypeface(null, android.graphics.Typeface.BOLD);

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setLayoutParams(new LinearLayout.LayoutParams(
										LinearLayout.LayoutParams.MATCH_PARENT, 10));

        LinearLayout card1 = createWhiteCard();
        card1.setOrientation(LinearLayout.VERTICAL);
        card1.addView(createText(isEnglish ? "Standard Test Results" : "标准测试结果", 14, Color.parseColor("#757575")));

        tvSeqWrite = createResultText(isEnglish ? "Sequential Write: --" : "顺序写入: --");
        tvSeqRead = createResultText(isEnglish ? "Sequential Read: --" : "顺序读取: --");
        tvRandWrite = createResultText(isEnglish ? "Random Write: --" : "随机写入: --");
        tvRandRead = createResultText(isEnglish ? "Random Read: --" : "随机读取: --");

        card1.addView(tvSeqWrite);
        card1.addView(tvSeqRead);
        card1.addView(tvRandWrite);
        card1.addView(tvRandRead);

        chartContainer = createWhiteCard();
        chartContainer.setOrientation(LinearLayout.VERTICAL);
        chartContainer.setVisibility(View.GONE);

        chartView = new SpeedChartView(this);
        chartView.setLayoutParams(new LinearLayout.LayoutParams(
									  LinearLayout.LayoutParams.MATCH_PARENT, 280));

        tvAvgSpeed = createText(getUIText(6), 13, Color.parseColor("#616161"));
        tvMaxSpeed = createText(getUIText(7), 13, Color.parseColor("#616161"));
        tvMinSpeed = createText(getUIText(8), 13, Color.parseColor("#616161"));
        tvDuration = createText(getUIText(9), 13, Color.parseColor("#616161"));

        chartContainer.addView(chartView);
        chartContainer.addView(tvAvgSpeed);
        chartContainer.addView(tvMaxSpeed);
        chartContainer.addView(tvMinSpeed);
        chartContainer.addView(tvDuration);

        content.addView(tvStatus);
        content.addView(progressBar);
        content.addView(card1);
        content.addView(chartContainer);

        scroll.addView(content);
        parent.addView(scroll);
    }

    private void createButtons(LinearLayout parent) {
        LinearLayout btnLayout = new LinearLayout(this);
        btnLayout.setOrientation(LinearLayout.VERTICAL);
        btnLayout.setGravity(Gravity.CENTER_HORIZONTAL);
        btnLayout.setPadding(20, 15, 20, 25);

        btnStart = createBlueButton(isEnglish ? "StandardMode" : "标准测试", new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					if (!isContinuousTesting) startStandardTest();
				}
			});

        btnContinuous = createBlueButton(isEnglish ? "Continuous R/W (15s)" : "持续读写测试(15秒)", new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					if (!isTesting) startContinuousTest();
				}
			});

        btnLayout.addView(btnStart);
        btnLayout.addView(btnContinuous);
        parent.addView(btnLayout);
    }

    private void createBottomBar(LinearLayout parent) {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setPadding(15, 12, 15, 20);
        bar.setBackgroundColor(Color.parseColor("#F5F5F5"));

        btnStorageInfo = createSimpleButton(isEnglish ? "Storage" : "存储详情", new View.OnClickListener() {
				@Override
				public void onClick(View v) { showStorageInfo(); }
			});

        btnLanguage = createSimpleButton(isEnglish ? "EN" : "中文", new View.OnClickListener() {
				@Override
				public void onClick(View v) { toggleLanguage(); }
			});

        btnAbout = createSimpleButton(isEnglish ? "About" : "关于", new View.OnClickListener() {
				@Override
				public void onClick(View v) { showAbout(); }
			});

        btnClearCache = createSimpleButton(isEnglish ? "Clear Cache" : "清除缓存", new View.OnClickListener() {
				@Override
				public void onClick(View v) { clearCache(); }
			});
        btnClearCache.setTextColor(Color.parseColor("#D32F2F"));

        bar.addView(btnStorageInfo);
        View spacer1 = new View(this);
        spacer1.setLayoutParams(new LinearLayout.LayoutParams(0, 1, 1));
        bar.addView(spacer1);
        bar.addView(btnLanguage);
        View spacer2 = new View(this);
        spacer2.setLayoutParams(new LinearLayout.LayoutParams(0, 1, 1));
        bar.addView(spacer2);
        bar.addView(btnAbout);
        View spacer3 = new View(this);
        spacer3.setLayoutParams(new LinearLayout.LayoutParams(0, 1, 1));
        bar.addView(spacer3);
        bar.addView(btnClearCache);
        parent.addView(bar);
    }

    private LinearLayout createWhiteCard() {
        LinearLayout card = new LinearLayout(this);
        card.setBackgroundColor(Color.WHITE);
        card.setPadding(20, 20, 20, 20);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(12);
        card.setBackground(bg);
        card.setElevation(2);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, 10, 0, 10);
        card.setLayoutParams(params);
        return card;
    }

    private TextView createText(String text, int size, int color) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(size);
        tv.setTextColor(color);
        tv.setPadding(0, 8, 0, 8);
        return tv;
    }

    private TextView createResultText(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(14);
        tv.setTextColor(Color.parseColor("#1976D2"));
        tv.setPadding(0, 10, 0, 10);
        return tv;
    }

    private Button createBlueButton(String text, View.OnClickListener listener) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextSize(15);
        btn.setTextColor(Color.WHITE);
        btn.setPadding(30, 12, 30, 12);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1976D2"));
        bg.setCornerRadius(20);
        btn.setBackground(bg);
        btn.setOnClickListener(listener);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, 10, 0, 10);
        btn.setLayoutParams(params);
        return btn;
    }

    private Button createSimpleButton(String text, View.OnClickListener listener) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextSize(11);
        btn.setBackgroundColor(Color.TRANSPARENT);
        btn.setPadding(8, 8, 8, 8);
        btn.setOnClickListener(listener);
        return btn;
    }

    private void showStorageInfo() {
        if (storageDirs.length == 0) return;
        final File dir = storageDirs[storageSpinner.getSelectedItemPosition()];
        try {
            final StatFs stat = new StatFs(dir.getAbsolutePath());
            final long blockSize = stat.getBlockSizeLong();
            final long totalBlocks = stat.getBlockCountLong();
            final long availBlocks = stat.getAvailableBlocksLong();

            final long totalSpace = totalBlocks * blockSize;
            final long availSpace = availBlocks * blockSize;

            String info = (isEnglish ? "Path: " : "路径: ") + dir.getAbsolutePath() + "\n\n" +
				(isEnglish ? "Total: " : "总容量: ") + formatSize(totalSpace) + "\n" +
				(isEnglish ? "Available: " : "可用空间: ") + formatSize(availSpace) + "\n" +
				(isEnglish ? "Block Size: " : "块大小: ") + formatSize(blockSize) + "\n" +
				(isEnglish ? "File System: " : "文件系统: ") + detectFileSystem(dir);

            Button btnBrowse = new Button(this);
            btnBrowse.setText(isEnglish ? "Browse Files" : "浏览文件");
            btnBrowse.setTextSize(14);
            btnBrowse.setTextColor(Color.WHITE);
            btnBrowse.setBackgroundColor(Color.parseColor("#388E3C"));
            btnBrowse.setPadding(20, 15, 20, 15);
            btnBrowse.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						currentBrowseDir = dir;
						showFileBrowser(dir);
					}
				});

            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(20, 20, 20, 20);

            TextView tvInfo = new TextView(this);
            tvInfo.setText(info);
            tvInfo.setTextSize(13);
            tvInfo.setPadding(0, 0, 0, 20);

            layout.addView(tvInfo);
            layout.addView(btnBrowse);

            new AlertDialog.Builder(this)
                .setTitle(isEnglish ? "Storage Details" : "存储介质详情")
                .setView(layout)
                .setPositiveButton(isEnglish ? "OK" : "确定", null)
                .show();
        } catch (Exception e) {
            Toast.makeText(this, isEnglish ? "Failed: " + e.getMessage() : "获取失败: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
    private void showFileBrowser(final File currentDir) {
        File[] files = currentDir.listFiles();
        if (files == null) {
            showToast(isEnglish ? "Access denied" : "无法访问");
            return;
        }
        Arrays.sort(files, new Comparator<File>() {
				@Override
				public int compare(File f1, File f2) {
					if (f1.isDirectory() && !f2.isDirectory()) return -1;
					if (!f1.isDirectory() && f2.isDirectory()) return 1;
					return f1.getName().toLowerCase().compareTo(f2.getName().toLowerCase());
				}
			});

        final List<File> fileList = new ArrayList<File>();
        final List<String> displayList = new ArrayList<String>();

        //上一级
        File parentDir = currentDir.getParentFile();
        if (parentDir != null && parentDir.canRead()) {
            fileList.add(parentDir);
            displayList.add(isEnglish ? ".. (Parent Directory)" : ".. (返回上一级)");
        }

        // 添加文件
        for (File f : files) {
            if (f.canRead()) {
                fileList.add(f);
                String prefix = f.isDirectory() ? "[DIR] " : "[FILE] ";
                displayList.add(prefix + f.getName());
            }
        }

        final File[] finalFiles = fileList.toArray(new File[0]);
        final String[] items = displayList.toArray(new String[0]);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(currentDir.getAbsolutePath());
        builder.setItems(items, new android.content.DialogInterface.OnClickListener() {
				@Override
				public void onClick(android.content.DialogInterface dialog, int which) {
					File selectedFile = finalFiles[which];
					if (selectedFile.isDirectory()) {
						// 点击进入文件夹
						showFileBrowser(selectedFile);
					} else {
						// 文件信息
						String info = (isEnglish ? "File: " : "文件: ") + selectedFile.getName() + "\n" +
							(isEnglish ? "Size: " : "大小: ") + formatSize(selectedFile.length()) + "\n" +
							(isEnglish ? "Path: " : "路径: ") + selectedFile.getAbsolutePath();

						new AlertDialog.Builder(MainActivity.this)
							.setTitle(isEnglish ? "File Info" : "文件信息")
							.setMessage(info)
							.setPositiveButton(isEnglish ? "OK" : "确定", null)
							.show();
					}
				}
			});
        builder.setPositiveButton(isEnglish ? "Close" : "关闭", null);
        builder.show();
    }

    private String formatSize(long bytes) {
        if (bytes >= 1073741824) return String.format(Locale.US, "%.2f GB", bytes / 1073741824.0);
        if (bytes >= 1048576) return String.format(Locale.US, "%.2f MB", bytes / 1048576.0);
        return String.format(Locale.US, "%.2f KB", bytes / 1024.0);
    }

    private String detectFileSystem(File dir) {
        try {
            StatFs stat = new StatFs(dir.getAbsolutePath());
            long blockSize = stat.getBlockSizeLong();
            long totalBlocks = stat.getBlockCountLong();
            long totalSpace = blockSize * totalBlocks;

            if (totalSpace > 10737418240L) {
                if (blockSize == 4096) return isEnglish ? "ext4 / F2FS" : "ext4 / F2FS";
                if (blockSize == 1024 || blockSize == 2048) return "FAT32";
                if (blockSize == 8192) return "exFAT";
            }
            return isEnglish ? "ext4 / F2FS" : "ext4 / F2FS";
        } catch (Exception e) {
            return isEnglish ? "Unknown/Not allowed" : "未知 (权限受限)";
        }
    }

    private void startStandardTest() {
        if (storageDirs.length == 0) {
            showToast(isEnglish ? "No storage device found" : "未找到存储设备");
            return;
        }
        isTesting = true;
        btnStart.setEnabled(false);
        tvStatus.setText(isEnglish ? "Testing.." : "测试中...");
        chartContainer.setVisibility(View.GONE);

        new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						final File testDir = storageDirs[storageSpinner.getSelectedItemPosition()];
						if (!testDir.exists()) testDir.mkdirs();

						final File testFile = new File(testDir, "test.bin");
						if (testFile.exists()) testFile.delete();
						testFile.createNewFile();

						long size = 20 * 1024 * 1024;
						byte[] buffer = new byte[1024 * 1024];

						RandomAccessFile raf = new RandomAccessFile(testFile, "rw");
						long start = System.nanoTime();
						long written = 0;
						while (written < size) {
							int chunk = (int) Math.min(buffer.length, size - written);
							raf.write(buffer, 0, chunk);
							written += chunk;
						}
						raf.close();
						final double seqWrite = calcSpeed(size, start);

						raf = new RandomAccessFile(testFile, "r");
						start = System.nanoTime();
						while (raf.read(buffer) != -1) {}
						raf.close();
						final double seqRead = calcSpeed(size, start);

						raf = new RandomAccessFile(testFile, "rw");
						buffer = new byte[4096];
						Random rand = new Random();
						start = System.nanoTime();
						for (int i = 0; i < 500; i++) {
							raf.seek(rand.nextInt((int)(size - 4096)));
							raf.write(buffer);
						}
						raf.close();
						final double randWrite = calcSpeed(500L * 4096, start);

						raf = new RandomAccessFile(testFile, "r");
						buffer = new byte[4096];
						start = System.nanoTime();
						for (int i = 0; i < 500; i++) {
							raf.seek(rand.nextInt((int)(size - 4096)));
							raf.read(buffer);
						}
						raf.close();
						final double randRead = calcSpeed(500L * 4096, start);

						testFile.delete();

						mainHandler.post(new Runnable() {
								@Override
								public void run() {
									tvSeqWrite.setText(String.format(Locale.US, isEnglish ? 
																	 "Sequential Write: %.2f MB/s" : "顺序写入: %.2f MB/s", seqWrite));
									tvSeqRead.setText(String.format(Locale.US, isEnglish ? 
																	"Sequential Read: %.2f MB/s" : "顺序读取: %.2f MB/s", seqRead));
									tvRandWrite.setText(String.format(Locale.US, isEnglish ? 
																	  "Random Write: %.2f MB/s" : "随机写入: %.2f MB/s", randWrite));
									tvRandRead.setText(String.format(Locale.US, isEnglish ? 
																	 "Random Read: %.2f MB/s" : "随机读取: %.2f MB/s", randRead));
									tvStatus.setText(isEnglish ? "Complete" : "测试完成");
									btnStart.setEnabled(true);
									isTesting = false;
								}
							});
					} catch (final Exception e) {
						mainHandler.post(new Runnable() {
								@Override
								public void run() {
									tvStatus.setText(isEnglish ? "Failed" : "测试失败");
									Toast.makeText(MainActivity.this, isEnglish ? "Error: " + e.getMessage() : "错误: " + e.getMessage(), Toast.LENGTH_LONG).show();
									btnStart.setEnabled(true);
									isTesting = false;
								}
							});
					}
				}
			}).start();
    }

    private void startContinuousTest() {
        if (storageDirs.length == 0) {
            showToast(isEnglish ? "No storage device found" : "未找到存储设备");
            return;
        }
        isContinuousTesting = true;
        isTesting = true;
        btnContinuous.setEnabled(false);
        tvStatus.setText(isEnglish ? "Testing..." : "持续测试中...");
        chartContainer.setVisibility(View.VISIBLE);
        if (chartView != null) chartView.clear();

        final List<Float> readSpeeds = new ArrayList<Float>();
        final List<Float> writeSpeeds = new ArrayList<Float>();
        final long startTime = System.currentTimeMillis();
        final long testDuration = 15000;
        final long sampleInterval = 1000;

        new Thread(new Runnable() {
				@Override
				public void run() {
					File testFile = null;
					try {
						final File testDir = storageDirs[storageSpinner.getSelectedItemPosition()];
						if (!testDir.exists()) testDir.mkdirs();

						testFile = new File(testDir, "rw_bench.bin");
						if (testFile.exists()) testFile.delete();
						testFile.createNewFile();

						RandomAccessFile raf = new RandomAccessFile(testFile, "rw");
						byte[] fillBuf = new byte[1024 * 1024];
						for(int i=0; i<50; i++) raf.write(fillBuf);
						raf.close();

						raf = new RandomAccessFile(testFile, "rw");
						byte[] buffer = new byte[1024 * 1024];
						Random rand = new Random();

						long lastSampleTime = System.currentTimeMillis();
						long ioBytesR = 0, ioBytesW = 0;
						long ioTimeRNs = 0, ioTimeWNs = 0;

						while (System.currentTimeMillis() - startTime < testDuration && isContinuousTesting) {
							long fileSize = testFile.length();
							if (fileSize < 50 * 1024 * 1024) {
								raf.seek(fileSize);
								raf.write(buffer);
								fileSize = testFile.length();
							}

							long pos = rand.nextInt((int) Math.max(1, fileSize - buffer.length));

							long opStart = System.nanoTime();
							raf.seek(pos); 
							raf.write(buffer);
							ioTimeWNs += System.nanoTime() - opStart;
							ioBytesW += buffer.length;

							pos = rand.nextInt((int) Math.max(1, fileSize - buffer.length));
							opStart = System.nanoTime();
							raf.seek(pos);
							raf.read(buffer);
							ioTimeRNs += System.nanoTime() - opStart;
							ioBytesR += buffer.length;

							long now = System.currentTimeMillis();
							if (now - lastSampleTime >= sampleInterval) {
								double speedW = (ioBytesW / 1048576.0) / (ioTimeWNs / 1_000_000_000.0);
								double speedR = (ioBytesR / 1048576.0) / (ioTimeRNs / 1_000_000_000.0);

								readSpeeds.add((float)speedR);
								writeSpeeds.add((float)speedW);

								final float rSpd = (float)speedR;
								final float wSpd = (float)speedW;
								final int seconds = (int)((now - startTime) / 1000);

								mainHandler.post(new Runnable() {
										@Override
										public void run() {
											if (chartView != null) chartView.addDataPoints(rSpd, wSpd);
											tvDuration.setText((isEnglish ? "Duration: " : "时长: ") + seconds + "s");
										}
									});

								ioBytesR = 0; ioBytesW = 0;
								ioTimeRNs = 0; ioTimeWNs = 0;
								lastSampleTime = now;
							}
						}
						raf.close();

						float maxR = 0, maxW = 0, minR = Float.MAX_VALUE, minW = Float.MAX_VALUE;
						float sumR = 0, sumW = 0;
						for (float s : readSpeeds) { maxR = Math.max(maxR, s); minR = Math.min(minR, s); sumR += s; }
						for (float s : writeSpeeds) { maxW = Math.max(maxW, s); minW = Math.min(minW, s); sumW += s; }

						final float avgR = readSpeeds.isEmpty() ? 0 : sumR / readSpeeds.size();
						final float avgW = writeSpeeds.isEmpty() ? 0 : sumW / writeSpeeds.size();
						final float finalMaxR = maxR, finalMaxW = maxW;
						final float finalMinR = minR, finalMinW = minW;

						mainHandler.post(new Runnable() {
								@Override
								public void run() {
									tvAvgSpeed.setText(String.format(Locale.US, isEnglish ? 
																	 "Avg R: %.2f | W: %.2f MB/s" : "平均 读: %.2f | 写: %.2f MB/s", avgR, avgW));
									tvMaxSpeed.setText(String.format(Locale.US, isEnglish ? 
																	 "Peak R: %.2f | W: %.2f MB/s" : "峰值 读: %.2f | 写: %.2f MB/s", finalMaxR, finalMaxW));
									tvMinSpeed.setText(String.format(Locale.US, isEnglish ? 
																	 "Min R: %.2f | W: %.2f MB/s" : "谷值 读: %.2f | 写: %.2f MB/s", finalMinR, finalMinW));
									if (chartView != null) chartView.setMaxValue(Math.max(finalMaxR, finalMaxW) * 1.2f);
								}
							});

						mainHandler.post(new Runnable() {
								@Override
								public void run() {
									tvStatus.setText(isEnglish ? "Complete" : "测试完成");
									btnContinuous.setEnabled(true);
									isTesting = false;
									isContinuousTesting = false;
								}
							});

					} catch (final Exception e) {
						mainHandler.post(new Runnable() {
								@Override
								public void run() {
									tvStatus.setText(isEnglish ? "Failed" : "测试失败");
									Toast.makeText(MainActivity.this, isEnglish ? "Error: " + e.getMessage() : "错误: " + e.getMessage(), Toast.LENGTH_LONG).show();
									btnContinuous.setEnabled(true);
									isTesting = false;
									isContinuousTesting = false;
								}
							});
					} finally {
						if (testFile != null && testFile.exists()) {
							testFile.delete();
						}
					}
				}
			}).start();
    }

    private void clearCache() {
        try {
            deleteDir(getCacheDir());
            File[] extCaches = getExternalCacheDirs();
            if (extCaches != null) {
                for (File dir : extCaches) if (dir != null) deleteDir(dir);
            }
            showToast(isEnglish ? "Cache cleared" : "缓存已清除");
        } catch (Exception e) {
            showToast(isEnglish ? "Clear failed" : "清除失败");
        }
    }

    private void deleteDir(File dir) {
        if (dir.isDirectory()) {
            File[] files = dir.listFiles();
            if (files != null) for (File f : files) deleteDir(f);
        }
        dir.delete();
    }

    private void showAbout() {
        String msg = isEnglish ? 
            "Disctester(DT) v0.6\n\n" +
            "What's new?:\n" +
            "1.Browse Files(WIP)\n" +
            "2.English is now SUPPORTREDED!\n" +
            "3.Remake R/W Testing\n" +
            "Whats's More?\n" +
            "Coming 0.7:Finish file browser(LOL)\n\n" +
            "Made by (waffme/w3_Dev)" :
			//
            "一个自己制作的测速app v0.6\n\n" +
            "更新日志:\n" +
            "1.文件浏览器(没做好)\n" +
            "2.支持英文\n" +
            "3.重写了R/W测试逻辑\n" +
            "会更新什么？\n" +
            "0.7版本：完善文件浏览器\n" +
            "LOLOLOL\n\n" +
            "By (waffme/w3_Dev)";

        new AlertDialog.Builder(this)
            .setTitle(isEnglish ? "About DiscTester(DT)" : "关于 DiscTester")
            .setMessage(msg)
            .setPositiveButton(isEnglish ? "OK" : "确定", null)
            .show();
    }

    private void showError(String msg) {
        TextView tv = new TextView(this);
        tv.setText(msg);
        tv.setPadding(20, 20, 20, 20);
        setContentView(tv);
    }

    private void showToast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private double calcSpeed(long bytes, long startNano) {
        double seconds = (System.nanoTime() - startNano) / 1_000_000_000.0;
        return (bytes / 1048576.0) / seconds;
    }
}
