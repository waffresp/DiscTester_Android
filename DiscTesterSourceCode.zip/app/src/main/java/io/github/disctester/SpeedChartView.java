package io.github.disctester;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

public class SpeedChartView extends View {
    private List<Float> readSpeeds = new ArrayList<Float>();
    private List<Float> writeSpeeds = new ArrayList<Float>();
    private Paint readPaint, writePaint, gridPaint, textPaint, legendPaint;
    private float maxValue = 0;

    public SpeedChartView(Context context) { super(context); init(); }
    public SpeedChartView(Context context, AttributeSet attrs) { super(context, attrs); init(); }

    private void init() {
        // 红读
        readPaint = new Paint();
        readPaint.setColor(Color.parseColor("#D32F2F"));
        readPaint.setStrokeWidth(3);
        readPaint.setStyle(Paint.Style.STROKE);
        readPaint.setAntiAlias(true);

        // 蓝写---这个可能不标准
        writePaint = new Paint();
        writePaint.setColor(Color.parseColor("#1976D2"));
        writePaint.setStrokeWidth(3);
        writePaint.setStyle(Paint.Style.STROKE);
        writePaint.setAntiAlias(true);

        gridPaint = new Paint();
        gridPaint.setColor(Color.parseColor("#E0E0E0"));
        gridPaint.setStrokeWidth(1);

        textPaint = new Paint();
        textPaint.setColor(Color.parseColor("#757575"));
        textPaint.setTextSize(12);
        textPaint.setAntiAlias(true);

        legendPaint = new Paint();
        legendPaint.setAntiAlias(true);
        legendPaint.setTextSize(13);
    }

    public void addDataPoints(float read, float write) {
        readSpeeds.add(read);
        writeSpeeds.add(write);
        if (read > maxValue) maxValue = read;
        if (write > maxValue) maxValue = write;
        if (readSpeeds.size() > 30) {
            readSpeeds.remove(0);
            writeSpeeds.remove(0);
        }
        postInvalidate();
    }

    public void clear() {
        readSpeeds.clear();
        writeSpeeds.clear();
        maxValue = 0;
        postInvalidate();
    }

    public void setMaxValue(float max) {
        maxValue = max;
        postInvalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int width = getWidth();
        int height = getHeight();
        int padding = 50;
        int chartHeight = height - padding * 2;
        int chartWidth = width - padding * 2;

        //y轴
        for (int i = 0; i <= 4; i++) {
            float y = padding + (chartHeight / 4.0f) * i;
            canvas.drawLine(padding, y, width - padding, y, gridPaint);
            float value = maxValue - (maxValue / 4.0f) * i;
            canvas.drawText(String.format("%.1f", value), 5, y + 4, textPaint);
        }

        //x轴
        for (int i = 0; i <= 5; i++) {
            float x = padding + (chartWidth / 5.0f) * i;
            canvas.drawText(i * 3 + "s", x - 10, height - 10, textPaint);
        }

        if (maxValue > 0 && !readSpeeds.isEmpty()) {
            float pointSpacing = chartWidth / 29.0f;

            // 绘制红线 (读取)
            Path readPath = new Path();
            float startY_R = padding + chartHeight - (readSpeeds.get(0) / maxValue) * chartHeight;
            readPath.moveTo(padding, startY_R);
            for (int i = 1; i < readSpeeds.size(); i++) {
                float x = padding + i * pointSpacing;
                float y = padding + chartHeight - (readSpeeds.get(i) / maxValue) * chartHeight;
                readPath.lineTo(x, y);
            }
            canvas.drawPath(readPath, readPaint);

            // 绘制蓝线 (写入)
            Path writePath = new Path();
            float startY_W = padding + chartHeight - (writeSpeeds.get(0) / maxValue) * chartHeight;
            writePath.moveTo(padding, startY_W);
            for (int i = 1; i < writeSpeeds.size(); i++) {
                float x = padding + i * pointSpacing;
                float y = padding + chartHeight - (writeSpeeds.get(i) / maxValue) * chartHeight;
                writePath.lineTo(x, y);
            }
            canvas.drawPath(writePath, writePaint);
        }

        
        Paint borderPaint = new Paint();
        borderPaint.setColor(Color.parseColor("#BDBDBD"));
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(1);
        canvas.drawRect(padding, padding, width - padding, height - padding, borderPaint);

        
        legendPaint.setColor(Color.parseColor("#D32F2F"));
        canvas.drawText("● 读取速度", padding, padding - 15, legendPaint);
        legendPaint.setColor(Color.parseColor("#1976D2"));
        canvas.drawText("● 写入速度", padding + 110, padding - 15, legendPaint);
    }
}
